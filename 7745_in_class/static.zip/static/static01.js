//static generation

inlets = 10;

var sketch = new JitterObject("jit.gl.sketch", "static"); //create jit.gl.sketch object with the name 'static'

sketch.glblendfunc("gl_src_alpha","gl_one_minus_src_alpha");
sketch.blend_enable=1; //enable alpha channel
sketch.depth_enable=0;


//variables 
var density = 0;;	//how many pieces of static per bang
var wLow = 0;		//random w/h within range
var wHigh = 0;
var hLow = 0;
var hHigh = 0;
var sLow = 0;		//random stroke color within range
var sHigh = 0;
var fLow = 0;		//random fill opacity within range
var fHigh = 0;

//we're going for 1280 x 720, so our aspect ratio will be 6:9
//height is -1 to 1 in openGL
//6:9 = 1:1.5
//width = -1.5 tp 1.5.

var yHigh = 2.;
var yLow = -2.;
var xHigh = 3.;
var xLow = -3.;


function msg_float(a) {
	
	switch(inlet) {
		
		case(1):
		density = a;
		break;
		
		case(2):
		wLow = scale(0., 1280., 0., 3., a);
		break;
		
		case(3):
		wHigh = scale(0., 1280., 0., 3., a);
		break;
		
		case(4):
		hLow = scale(0., 640., 0., 1.5, a);
		break;
		
		case(5):
		hHigh = scale(0., 640., 0., 1.5, a);
		break;
		
		case(6):
		fLow = a;
		break;
		
		case(7):
		fHigh = a;
		break;
		
		case(8):
		sLow = a;
		break;
		
		case(9):
		sHigh = a;
		break;
				
	}
	
	bang();
	
}


function bang() { // everytime js object recieve bang
	
sketch.reset();	
//draw background
sketch.glcolor(0., 0., 0., 1.);
sketch.glrect(-1.475, 0.83, 1.475, -8.3);
	
	for (x = density; x>0; x--) {
		//draw a circle in a random location
		staticGenerate();
	}
}


function staticGenerate(){
	//random x value
	var x = scale(0.,1.,xLow,xHigh,Math.random()); //randomized x
	var y = scale(0.,1.,yLow,yHigh,Math.random()); //randomized y
	var w = scale(0.,1.,wLow,wHigh,Math.random()); //randomized w
	var h = scale(0.,1.,hLow,hHigh,Math.random()); //randomized h
	var s = scale(0.,1.,sLow,sHigh,Math.random()); //randomized s
	var f = scale(0.,1.,fLow,fHigh,Math.random()); //randomized f
	
	drawCircle(x,y,w,h,f,s);
	
	}
	
function drawCircle(xpos,ypos,width,height,alpha,stroke){
	
	var xx = xpos;
	var yy = ypos;
	var ww = width/2;
	var hh = height/2;
	var aa = alpha;
	var ss = stroke;
	
	sketch.glcolor(1., 1., 1., aa);
	sketch.glpushmatrix();
	sketch.gltranslate(xx - xx/2,yy - yy/2); //center the dot on xy coordinate
	sketch.ellipse(ww,hh);
	sketch.glcolor(1., 1., 1., ss);
	sketch.frameellipse(ww,hh);
	sketch.glpopmatrix();
	
}

function scale(a,b,c,d,e) { //min1, max1, min2, max2, value
	var min1=a;
	var max1=b;
	var min2=c;
	var max2=d;
	var value = e;
	var newValue = (((value-min1)*(max2-min2))/(max1-min1))+min2;
	
	return newValue; // scaled value
}

